# Data-Intelligence 
Proyecto de predicci�n sobre datos de denuncias desarrollado en Python y PostgreSQL.

## Instalaci�n
1. Crear entorno virtual: `python -m venv venv`
2. Activar entorno: `venv\Scripts\activate`
