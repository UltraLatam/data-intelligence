# app/__init__.py
"""
Sistema de Gestión de Denuncias Ciudadanas
"""
__version__ = "1.0.0"
__author__ = "Sistema de Denuncias"
__description__ = "Plataforma web para gestión de denuncias ciudadanas"
# 👇 Importante: aquí NO importes routers ni módulos
